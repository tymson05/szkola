﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoleOkregu
{
    internal class Prostokat
    {
        int bok1, bok2;
        public Prostokat() {
            bok1 = 0;
            bok2 = 0;
        }

        public Prostokat(int podana)
        {
            bok1 = podana;
            bok2 = 0;
        }

        public Prostokat(int podana1, int podana2)
        {
            bok1 = podana1;
            bok2 = podana2;
        }

        public double LiczPole()
        {
            if (bok2 == 0)
            {
                return bok1 * bok1;
            }
            else return bok1 * bok2;
        }
    }
}
