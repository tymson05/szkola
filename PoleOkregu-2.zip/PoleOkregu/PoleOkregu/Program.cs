﻿using PoleOkregu;

Okrag okrag = new Okrag(5);
Console.WriteLine(okrag.Pole());

Console.WriteLine(Okrag.liczbaOkregow);

Okrag okrag1 = new Okrag(10);
Okrag okrag2 = new Okrag(5);
Okrag okrag3 = new Okrag(15);
Okrag okrag4 = new Okrag(17);
Okrag okrag5 = new Okrag(28);

Console.WriteLine(Okrag.liczbaOkregow);