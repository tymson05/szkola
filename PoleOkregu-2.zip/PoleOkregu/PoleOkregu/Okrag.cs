﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoleOkregu
{
    internal class Okrag
    {
        private int promien;
        public static string nazwa = "";
        public static int liczbaOkregow = 0;

        public Okrag()
        {
            promien = 0;
            liczbaOkregow++;
        }

        public Okrag(int podana = 0)
        {
            promien = podana;
            liczbaOkregow++;
        }

        public double Pole()
        {
            return Math.PI * Math.Pow(promien, 2);
        }
    }
}
