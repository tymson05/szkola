﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace teb
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private bool czyPrzenoszenie = false;// czy trwa przenoszenie?
        private Point punktPoczątkowy;//poczatkowa pozycja myszy
        private Cursor kursor;
        public MainWindow()
        {
            InitializeComponent();
        }


        private void mousedown(object sender, MouseButtonEventArgs e)
        {
            if(e.ButtonState == Mouse.LeftButton)
            {
                czyPrzenoszenie=true;
                kursor = Cursor;
                Cursor = Cursors.Hand;
                punktPoczątkowy = e.GetPosition(this);
            }
        }

        private void mousemove(object sender, MouseEventArgs e)
        {
            if (czyPrzenoszenie)
            {
                Vector przesunięcie = e.GetPosition(this) - punktPoczątkowy;
                Left += przesunięcie.X;
                Top += przesunięcie.Y;
            }
        }

        private void mouseup(object sender, MouseButtonEventArgs e)
        {
            if (czyPrzenoszenie)
            {
                Cursor = kursor;
                czyPrzenoszenie = false;
            }
        }

        private void keydownwindow(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape) this.Close();
        }
    }
}
